# Sampling comparison

Success requires both MoveIt success and the interpolated path audit. Timing runs exclude RViz sample publication unless requested.

| Mode | Success | Action median (s), all | Action p95 (s), all | Valid/attempt |
|---|---:|---:|---:|---:|
| gmm | 15/15 | 0.1431 | 0.3286 | 0.5016 |
| gmr_path/0.005m | 11/15 | 0.1992 | 3.0674 | 0.5954 |
| hybrid/0.005m | 15/15 | 0.1421 | 0.2703 | 0.5911 |
| gmr_path/0.015m | 15/15 | 0.1900 | 0.5171 | 0.5988 |
| hybrid/0.015m | 15/15 | 0.1082 | 0.1915 | 0.6384 |
| gmr_path/0.03m | 15/15 | 0.1289 | 0.2881 | 0.6892 |
| hybrid/0.03m | 15/15 | 0.1483 | 0.3295 | 0.6038 |
| reference_ik | 5/15 | 0.1107 | 0.2114 | — |

Median stage times (seconds; nested sub-timers are shown separately):

| Mode | Reproduction | RL | Sampler setup | Sampling | Online IK | Anchor IK | Jacobian setup | FK mapping |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| gmm | 0.0082 | 0.0009 | 0.0000 | 0.0178 | 0.0174 | 0.0000 | 0.0000 | 0.0000 |
| gmr_path/0.005m | 0.0082 | 0.0009 | 0.0000 | 0.0239 | 0.0237 | 0.0000 | 0.0000 | 0.0000 |
| hybrid/0.005m | 0.0082 | 0.0009 | 0.0000 | 0.0149 | 0.0146 | 0.0000 | 0.0000 | 0.0000 |
| gmr_path/0.015m | 0.0082 | 0.0009 | 0.0000 | 0.0211 | 0.0208 | 0.0000 | 0.0000 | 0.0000 |
| hybrid/0.015m | 0.0082 | 0.0009 | 0.0000 | 0.0120 | 0.0118 | 0.0000 | 0.0000 | 0.0000 |
| gmr_path/0.03m | 0.0082 | 0.0009 | 0.0000 | 0.0230 | 0.0227 | 0.0000 | 0.0000 | 0.0000 |
| hybrid/0.03m | 0.0082 | 0.0009 | 0.0000 | 0.0285 | 0.0276 | 0.0000 | 0.0000 | 0.0000 |
| reference_ik | 0.0082 | 0.0009 | — | — | — | — | — | — |

GMR reference diagnostics (successful paths; missing values are unavailable):

| Variant | Mean reference deviation (m) | Max reference deviation (m) | EE obstacle clearance (m) |
|---|---:|---:|---:|
| gmm | 0.0658 | 0.1467 | 0.1271 |
| gmr_path/0.005m | 0.0610 | 0.1429 | 0.1293 |
| hybrid/0.005m | 0.0662 | 0.1383 | 0.1187 |
| gmr_path/0.015m | 0.0612 | 0.1163 | 0.1257 |
| hybrid/0.015m | 0.0579 | 0.1114 | 0.1113 |
| gmr_path/0.03m | 0.0427 | 0.0828 | 0.1069 |
| hybrid/0.03m | 0.0581 | 0.1191 | 0.1204 |
| reference_ik | — | — | 0.3124 |

Direct reference IK includes public-service validation/FK overhead and is a feasibility baseline, not an equal-overhead planner comparison.

Stage times overlap: draw/IK/FK/validity are inside sampling; anchor IK/Jacobian are inside setup. Do not add nested counters.
Clearance is the whole robot to padded world geometry (ACM respected), sampled along joint interpolation; it is not a continuous safety certificate.
The projected proposal is a local approximation. Valid targets and RRT tree vertices have different distributions.
Seeds cover custom proposals/IK seeds and trial order. OMPL, the default sampler and the IK plugin may have independent RNGs.
